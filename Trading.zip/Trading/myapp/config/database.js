
module.exports = {

    'url' : 'mongodb://localhost/stockTrekDB'

};


