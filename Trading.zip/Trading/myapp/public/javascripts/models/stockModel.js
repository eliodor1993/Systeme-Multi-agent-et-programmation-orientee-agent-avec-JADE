
var app = app || {};

app.stockModel = Backbone.Model.extend({
    defaults: {
        Name:'',
        Symbol: '',
        LastPrice: '',
        MarketCap: ''
    }

});
