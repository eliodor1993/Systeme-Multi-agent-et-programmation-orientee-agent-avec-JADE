
var app = app || {};

app.positionCollection = Backbone.Collection.extend({

    model: app.positionModel,

    url:'/api/position'


});