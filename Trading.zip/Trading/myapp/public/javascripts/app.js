
var app = app || {};


$(function() {
    new app.mainView();

});