# tradeTracker

##Summary
App with password encrypted user authentication, real time market info, and data analysis. 

Purpose is to record and verify user's trade analyses. 

The user selects a trade, and based on a perceived future catalyst, makes a prediction on a selected timeline. The application will track the trade and return result information when the selected timeline is reached. 



##Stack
Backbone, Node, Express, NPM, Mongoose, Jade
